Congratulations on getting this bot!

How to set it up:

 - Extract into any directory
 - Go there
 - Windows: SHIFT+RIGHTCLICK on the background of the file explorer, then select "Open PowerShell Here"
 - Linux: Open terminal and cd into that path, then run "apt-get install ffmpeg" or the equivalent of your package manager
 - Make sure you have Java installed (version 8 - 14 (higher may work, but not guaranteed))
 - Type "java -jar ProjectorBotV2.jar your_bot_token_goes_here" in your powershell or terminal and press enter. DO NOT CLOSE THE WINDOW
 - It'll start converting. Once it says "DONE!", press CTRL+C to cancel the process
 - You have now set it up, to run it, follow the run instructions

How to run:

 - Go to the directory that you extracted the program to
 - Windows: SHIFT+RIGHTCLICK on the background of the file explorer, then select "Open PowerShell Here"
 - Linux: Open terminal and cd into that path

   // Start here if you are running it for the first time
 - Type "java -jar ProjectorBotV2.jar your_bot_token_goes_here" in your powershell or terminal and press enter. DO NOT CLOSE THE WINDOW
 - Bot should start running.

Commands:

 - "!play"
 - "!stop"

How to stop the bot:

 - CTRL+C in your terminal/powershell, and/or close it.

How to change the video:

 - Stop the bot
 - Replace vid.mp4 with any video you like. IT MUST BE NAMED "vid.mp4" - INCLUDING CAPITALIZATION!!
 - Delete vid_encoded and aud_encoded
 - Start the bot

Help:

 - TudbuT#2624 on Discord
 - The previous version had broken encoding and sometimes took hours without finishing.
   Sorry about that, it's fixed now.



~ TudbuT
